const yelpKey = '4akfwKSTtaGeC-SYN2bf-lVXLHde2o3izLILque4W4kLq3ZWLYtOtkkrP_hAR5iXIUh_UetZuDb9w_hSOHcOmWounVdN8H-lkCFqvdNCETJDxaodkzqP2sretFBiW3Yx';

module.exports = {
    yelpKey
}